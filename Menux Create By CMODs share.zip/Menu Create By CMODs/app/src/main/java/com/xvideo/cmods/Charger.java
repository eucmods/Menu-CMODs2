package com.xvideo.cmods;

import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import android.view.View.OnLongClickListener;
import com.layout.by.cmods.R;
import android.view.LayoutInflater;
import android.widget.Switch;
import android.graphics.drawable.GradientDrawable;
import android.app.AlertDialog;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.text.Html;
import android.graphics.PorterDuff;
import java.io.InputStream;
import android.graphics.drawable.Drawable;

public class Charger{

    private static WindowManager janela_menu;
	
	private static Context ctx;
	
	private static Service floater;

	private static ImageView DevTeam;

	private static FrameLayout Cmods_Frames;

	private static RelativeLayout collapseView;

	private static LinearLayout CoRingaModz_YT,Dev_cmods,BUTÃO_LAYOUT;//All Linear Layout
	
	static int cm_ods;

	public static native void Load(int feature, int Value);
	
	private static native String[] listfunction();
	
    private static void TEKASHI_TEAM(){
        
		Cmods_Frames = new FrameLayout(ctx);
        FrameLayout.LayoutParams fraLayoutParams = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        Cmods_Frames.setLayoutParams(fraLayoutParams);

        RelativeLayout Subs_Relative = new RelativeLayout(ctx);
        RelativeLayout.LayoutParams relative_Sub = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT);
        Subs_Relative.setLayoutParams(relative_Sub);
        
		collapseView = new RelativeLayout(ctx);
        collapseView.setLayoutParams(relative_Sub);
		
		DevTeam = new ImageView(ctx);
		//DevTeam.setImageDrawable(ctx.getResources().getDrawable(R.drawable.aim_on));
		LinearLayout.LayoutParams CMODSDEV = new LinearLayout.LayoutParams(dp(65), dp(65));
        DevTeam.setLayoutParams(CMODSDEV);
		try {
            InputStream open = ctx.getAssets().open("cmIcon.png");
            DevTeam.setImageDrawable(Drawable.createFromStream(open, null));
            open.close();
		}
		catch(IOException ex) 
		{
			return;
		}
		collapseView.addView(DevTeam);
		
		Dev_cmods = new LinearLayout(ctx);
		Dev_cmods.setVisibility(View.GONE);
        Dev_cmods.setBackgroundColor(Color.parseColor("#990000"));
        Dev_cmods.setAlpha(0.99f);
		Dev_cmods.setGravity(17);
        Dev_cmods.setOrientation(LinearLayout.VERTICAL);
        Dev_cmods.setPadding(3, 3, 3, 3);
        android.graphics.drawable.GradientDrawable EBGJFGB = new android.graphics.drawable.GradientDrawable();
        EBGJFGB.setColor(Color.parseColor("#990000"));
        EBGJFGB.setCornerRadius(9);
        Dev_cmods.setBackground(EBGJFGB);
        if(Build.VERSION.SDK_INT >= 21) { 
		Dev_cmods.setElevation(100f); 
		}
        Dev_cmods.setLayoutParams(new LinearLayout.LayoutParams(dp(275), dp(320)));
		
		RelativeLayout relativeLayout = new RelativeLayout(ctx);
        relativeLayout.setLayoutParams(new RelativeLayout.LayoutParams(-2, -1));
        relativeLayout.setPadding(10, 10, 10, 10);
        relativeLayout.setVerticalGravity(16);
		
		Button close_menu = new Button(ctx);
		RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(11);
        close_menu.setText("FECHAR");
        close_menu.setTextColor(Color.parseColor("GRAY"));
        close_menu.getBackground().setAlpha(250);
        close_menu.setLayoutParams(layoutParams);
        android.graphics.drawable.GradientDrawable IECGCAA = new android.graphics.drawable.GradientDrawable();
        IECGCAA.setColor(Color.parseColor("#00000000"));
        IECGCAA.setCornerRadii(new float[] { 10, 10, 10, 10, 10, 10, 34, 34 });
        IECGCAA.setStroke(3, Color.parseColor("#FF9E9E9E"));
        close_menu.setBackground(IECGCAA);
		relativeLayout.addView(close_menu);
		close_menu.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
					collapseView.setVisibility(View.VISIBLE);
					Dev_cmods.setVisibility(View.GONE);
                }
            });
		LinearLayout Layout_Principal = new LinearLayout(ctx);
        LinearLayout.LayoutParams layout_LinearLayout_Principal = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        Layout_Principal.setLayoutParams(layout_LinearLayout_Principal);
		//Layout_Principal.setBackgroundColor(Color.parseColor("#ff000000"));
        Layout_Principal.setOrientation(LinearLayout.VERTICAL);

		ScrollView deslizamento = new ScrollView(ctx);
        LinearLayout.LayoutParams scrollView_Params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(170));
        deslizamento.setLayoutParams(scrollView_Params);
		
        TextView Titulo_do_Menu = new TextView(ctx);
        Titulo_do_Menu.setText("DEV TEAM");
        Titulo_do_Menu.setTextColor(Color.parseColor("WHITE"));
        Titulo_do_Menu.setTypeface(Typeface.DEFAULT_BOLD);
        Titulo_do_Menu.setTextSize(22.0f);
        Titulo_do_Menu.setPadding(10, 10, 10, 15);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 17;
        Titulo_do_Menu.setLayoutParams(layoutParams2);
		
		LinearLayout borda_1 = new LinearLayout(ctx);
        borda_1.setLayoutParams(new LinearLayout.LayoutParams(-1, 5));
        borda_1.setBackgroundColor(Color.parseColor("BLACK"));
		
		CoRingaModz_YT = new LinearLayout(ctx);
		CoRingaModz_YT.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, -1));
        CoRingaModz_YT.setOrientation(LinearLayout.VERTICAL);
        //patches.setVisibility(8);
		
		LinearLayout borda_2 = new LinearLayout(ctx);
		borda_2.setLayoutParams(new LinearLayout.LayoutParams(-1, 5));
        borda_2.setBackgroundColor(Color.parseColor("BLACK"));
        borda_2.setPadding(0, 0, 0, 10);
		
		BUTÃO_LAYOUT = new LinearLayout(ctx);
        BUTÃO_LAYOUT.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, -1));
        BUTÃO_LAYOUT.setOrientation(LinearLayout.VERTICAL);
		
		CoRingaModz_YT.addView(BUTÃO_LAYOUT);
		
		Dev_cmods.addView(Titulo_do_Menu);
		
		Dev_cmods.addView(borda_1);
		
		deslizamento.addView(CoRingaModz_YT);
		
		Layout_Principal.addView(deslizamento);
		
		Dev_cmods.addView(Layout_Principal);
		
		Dev_cmods.addView(borda_2);
		
		Subs_Relative.addView(collapseView);
		
		Dev_cmods.addView(relativeLayout);
		
		
		Subs_Relative.addView(Dev_cmods);
        Cmods_Frames.addView(Subs_Relative);
		MrEzCheatsYT();
		int flag;
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.N_MR1){
            flag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        }else {
            flag = WindowManager.LayoutParams.TYPE_PHONE;
        }
        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,flag, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = 0;
        params.y = 100;
        janela_menu = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
        janela_menu.addView(Cmods_Frames, params);
		//onFloatingWidgetLongClick();
		Cmods_Frames.setOnTouchListener(new View.OnTouchListener() {
				private int initialX;
				private int initialY;
				private float initialTouchX;
				private float initialTouchY;
				boolean isLongClick = false;
				Handler handler_longClick = new Handler();
				Runnable runnable_longClick = new Runnable() {
					@Override public void run() {
						isLongClick = true;
						Close_segurar();///SEGURAR ICON PARA FECHAR MENU
						
						//DevTeam.setVisibility(View.GONE);
					}
				};
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()) {
						case MotionEvent.ACTION_DOWN:
							initialX = params.x;
							initialY = params.y;
							initialTouchX = event.getRawX();
							initialTouchY = event.getRawY();
							handler_longClick.postDelayed(runnable_longClick, 1000);
							return true;
						case MotionEvent.ACTION_UP:
							int Xdiff = (int) (event.getRawX() - initialTouchX);
							int Ydiff = (int) (event.getRawY() - initialTouchY);
							handler_longClick.removeCallbacks(runnable_longClick);
							if (Xdiff < 10 && Ydiff < 10) {
								if (VerColapso()) {
									collapseView.setVisibility(View.GONE);
									Dev_cmods.setVisibility(View.VISIBLE);
								}
							}
							return true;
						case MotionEvent.ACTION_MOVE:
							params.x = initialX + (int) (event.getRawX() - initialTouchX);
							params.y = initialY + (int) (event.getRawY() - initialTouchY);
							janela_menu.updateViewLayout(Cmods_Frames, params);
							return true;
					}
					return false;
				}
			});
		}
		
	private static void MrEzCheatsYT(){
        String[] arrstring = listfunction();
        for (int i2 = 0; i2 < arrstring.length; ++i2) {
            final int n2 = i2;
            String string2 = arrstring[i2];
            if (string2.contains((CharSequence)"ۥۖۡۦۚۢ۠۟۬ۚۘۙۙ۫ۘۚ۠ۥۘۨۜۨ۟ۥۚ۠ۙ۫ۢۥۚ۠")) {
                Switch_List(string2.replace((CharSequence)"ۥۖۡۦۚۢ۠۟۬ۚۘۙۙ۫ۘۚ۠ۥۘۨۜۨ۟ۥۚ۠ۙ۫ۢۥۚ۠", (CharSequence)""), new InterfaceBool(){
                        @Override
                        public void OnWrite(boolean bl) {
							Load(n2, 0);
                        }
                    });
                continue;
            }
            if (string2.contains((CharSequence)"SeekBar_")) {
                String[] arrstring2 = string2.split("_");
                addSeekBar(arrstring2[1], Integer.parseInt((String)arrstring2[2]), Integer.parseInt((String)arrstring2[3]), new InterfaceInt(){
                        @Override
                        public void OnWrite(int n22) {
							Load(n2, n22);
                        }
                    });
                continue;
            }
        }
    }
	private static void Switch_List(String string2, final InterfaceBool interfaceBool) {
        final Switch sw = new Switch(ctx);
		sw.setText(string2);
        sw.setTextColor(Color.WHITE);
        sw.setPadding(10, 3, 3, 3);
        sw.setTextSize(13.0f);
        final GradientDrawable BackgroundCaixa = new GradientDrawable();
        BackgroundCaixa.setShape(0);
        BackgroundCaixa.setColor(-1);
        BackgroundCaixa.setCornerRadius((float) dp(10));
        BackgroundCaixa.setSize(dp(20), dp(20));
        BackgroundCaixa.setStroke(dp(1), -7829368);
        final GradientDrawable BackgrounSwitch = new GradientDrawable();
        BackgrounSwitch.setShape(0);
        BackgrounSwitch.setColor(-1);
        BackgrounSwitch.setStroke(dp(1), -7829368);
        BackgrounSwitch.setCornerRadius((float) dp(10));
        BackgrounSwitch.setSize(dp(20), dp(20));
        sw.setTrackDrawable(BackgroundCaixa);
        sw.setThumbDrawable(BackgrounSwitch);
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    interfaceBool.OnWrite(isChecked);
                    if(isChecked) {
                        sw.setTextColor(Color.parseColor("#ffffff"));
						BackgrounSwitch.setStroke(dp(1), Color.parseColor("#FF0000"));
						BackgroundCaixa.setStroke(dp(1), Color.parseColor("#FF0000"));
						BackgroundCaixa.setColor(Color.parseColor("#FF0000"));
					} else {
                        sw.setTextColor(Color.WHITE);
						BackgrounSwitch.setStroke(dp(1), -7829368);
						BackgroundCaixa.setStroke(dp(1), -7829368);
						BackgroundCaixa.setColor(-1);
                    }
                }
            });
        BUTÃO_LAYOUT.addView(sw);
    }
    private static void addSeekBar(String str, int progress, int max, InterfaceInt sb) {
        LinearLayout linearLayout = new LinearLayout(ctx);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(17);
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setBackgroundColor(Color.parseColor("#00000000"));
        TextView textView = new TextView(ctx);
        StringBuilder sb2 = new StringBuilder();
        sb2.append("<font face='monospace'><b>");
        sb2.append(str);
        sb2.append(": <font color='WHITE'>");
        sb2.append(progress);
        sb2.append("</b></font>");
        textView.setText(Html.fromHtml(sb2.toString()));
        textView.setTextColor(-1);
        textView.setTextColor(Color.WHITE);
        textView.setTextSize(12.0f);
        textView.setTypeface((Typeface) null, 1);
        SeekBar seekBar = new SeekBar(ctx);
        seekBar.setScaleY(1.0f);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        if (Build.VERSION.SDK_INT >= 21) {
            seekBar.getProgressDrawable().setTint(-1);
        }
        seekBar.setMax(max);
        seekBar.setProgress(progress);
        seekBar.getProgressDrawable().setColorFilter(Color.parseColor("#ffff7700"), PorterDuff.Mode.MULTIPLY);
        seekBar.getThumb().setColorFilter(Color.parseColor("#ffff7700"), PorterDuff.Mode.SRC_IN);
        final int i5 = progress;
        final SeekBar seekBar2 = seekBar;
        final InterfaceInt sb3 = sb;
        final TextView textView2 = textView;
        final String str3 = str;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                private String itv;
                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                public void onStopTrackingTouch(SeekBar seekBar) {
                }
                public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                    int i2 = i5;
                    if (i < i2) {
                        seekBar2.setProgress(i2);
                        sb3.OnWrite(i5);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml("<font face='monospace'><b>" + str3 + ": <font color='WHITE'>" + i5 + "</b></font>"));
                        return;
                    }
                    sb3.OnWrite(i);
                    textView2.setText(Html.fromHtml("<font face='monospace'><b>" + str3 + ": <font color='WHITE'>" + i + "</b></font>"));

                }
            });

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        // linearLayout.setLayoutParams(this.hr);
        BUTÃO_LAYOUT.addView(linearLayout);
    }
	
		
	private static boolean VerColapso() {
		return Cmods_Frames == null || Cmods_Frames.getVisibility() == View.VISIBLE;
    }
	public static void Destroy() {
        try {
            if (Cmods_Frames != null) Charger.janela_menu.removeView(Cmods_Frames);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
	public static void Init(Context context, Service service){
        try {
            ctx = context;
            floater = service;
			TEKASHI_TEAM();
        } catch (Exception e) {
            e.printStackTrace();
			Toast.makeText(ctx, e.toString(), Toast.LENGTH_LONG).show();
        }
    }
	private static void Close_segurar() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            cm_ods = 2038;
        } else {
            cm_ods = 2002;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(ctx, 5);
		builder.setTitle("CMODs Developer");
		builder.setMessage("Tem certeza de que deseja interromper o Hack?\nVocê não poderá acessar o Hack novamente até reabrir o Jogo!");
		builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					DevTeam.setVisibility(View.GONE);
					Dev_cmods.setVisibility(View.GONE);
					collapseView.setVisibility(View.GONE);
					showMessage("Closing...");
				}
			});
		builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});

		AlertDialog dialog = builder.create();
		dialog.getWindow().setType(cm_ods);
		dialog.show();
	}
	public static void showMessage(String txt){
		Toast.makeText(ctx, txt, Toast.LENGTH_LONG).show();
	}
    private static interface InterfaceBool {
        public void OnWrite(boolean var1);
    }

    private static interface InterfaceBtn {
        public void OnWrite();
    }

    private static interface InterfaceInt {
        public void OnWrite(int var1);
    }

    private static interface InterfaceStr {
        public void OnWrite(String var1);
    }
    private static int dp(int value){
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, ctx.getResources().getDisplayMetrics());
    }
}
