#include <pthread.h>
#include <jni.h>
#include <Substrate/SubstrateHook.h>
#include "Unity/Unity.h"
#include "memory/Memory.h"

#define getRealOffset(offset) AgetAbsoluteAddress("libil2cpp.so",offset)
#define TEKASHI(offset, ptr, orig) MSHookFunction((void *)getRealOffset(offset), (void *)ptr, (void **)&orig)

extern "C" {
JNIEXPORT jstring JNICALL
Java_com_xvideo_cmods_Charger_Title(JNIEnv *env, jobject thiz) {
    return env->NewStringUTF("SEO TEAM");
}
JNIEXPORT jstring JNICALL
Java_com_xvideo_cmods_Charger_Heading(JNIEnv *env, jobject thiz) {
    return env->NewStringUTF("Free Fire V1.68.1");
}

JNIEXPORT jobjectArray JNICALL
Java_com_xvideo_cmods_Charger_listfunction(JNIEnv *env,jobject activityObject)
{jobjectArray ret;
    const char *features[] = {
		///////////////AIM-BOT////////////////
		    "ۥۖۡۦۚۢ۠۟۬ۚۘۙۙ۫ۘۚ۠ۥۘۨۜۨ۟ۥۚ۠ۙ۫ۢۥۚ۠Aim Por Tiro",//[0]
           
            "SeekBar_AimFOV_0_360",//[1]
            
		    "ۥۖۡۦۚۢ۠۟۬ۚۘۙۙ۫ۘۚ۠ۥۘۨۜۨ۟ۥۚ۠ۙ۫ۢۥۚ۠ESP Line",//[2]
			
			"ۥۖۡۦۚۢ۠۟۬ۚۘۙۙ۫ۘۚ۠ۥۘۨۜۨ۟ۥۚ۠ۙ۫ۢۥۚ۠ESP Name",//[3]
			
			};int Total_Feature = (sizeof features/sizeof features[0]);
			ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass("java/lang/String"),env->NewStringUTF(""));int i;for (i = 0; i < Total_Feature; i++)env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));return (ret);
	}

struct Patch {
	
   // Memory aimlock1;
   
}Tekashi;


struct {
	
} CM;

JNIEXPORT void JNICALL
Java_com_xvideo_cmods_Charger_Load(
        JNIEnv *env,
        jobject activityObject,
        jint feature,
        jint Value) {
    __android_log_print(ANDROID_LOG_VERBOSE, "Mod Menu", "Feature: = %d", feature);
    __android_log_print(ANDROID_LOG_VERBOSE, "Mod Menu", "Value: = %d", Value);
    switch (feature) {
	    
        case 0:
            //addCM.aimFire = !CM.aimFire;
           break;
		   
		   case 1:
		//Add
		   break;
			
			case 2:
		//Add
            break;
		
			case 3:
			//add
			break;
    }
  }
}


void *hack_thread(void *) {
LOGI("Loading...");
    ProcMap il2cppMap;
    do {
        il2cppMap = Ptrace::getLibraryMap("libil2cpp.so");
        sleep(1);
    } while (!il2cppMap.isValid());
	//Tekashi.antbanned = Memory("libil2cpp.so", 0x28B9300, "\x00\x00\xA0\xE3\x1E\xFF\x2F\xE1", 8);///public static void NativeLog
	return NULL;
}

extern "C" 
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
JNIEnv *globalEnv;
vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);

pthread_t ptid;
pthread_create(&ptid, NULL, hack_thread, NULL);

return JNI_VERSION_1_6;
}
